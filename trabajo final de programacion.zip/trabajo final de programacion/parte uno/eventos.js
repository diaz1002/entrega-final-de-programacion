var fondo = document.querySelector('.fondo')
var nubes = document.querySelector('.nub')
var montañas = document.querySelector('.montañas')

montañas.addEventListener('click', animations)

function animations(){
montañas.classList.remove('sombra')
montañas.classList.add('exp')
nubes.classList.add('nubes_animadas')
}