var nubes = document.querySelector('.nubesimg')
var lagrimas = document.querySelector('.lagrimas')
var emma = document.querySelector('.emma')

emma.addEventListener('click', animations)

function animations(){
    nubes.classList.add('nubes_animadas')
    lagrimas.classList.remove('oculto')
    emma.classList.remove('sombra')
}